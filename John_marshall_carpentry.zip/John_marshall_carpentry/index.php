
<?php include 'header.php' ?>
	<section class="slider" id="home">
		<div class="container-fluid">
			<div class="row">
			    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
					<div class="header-backup"></div>
			        <!-- Wrapper for slides -->
			        <div class="carousel-inner" role="listbox">
			            <div class="item active">
			            	<img src="img/slide-one.jpg" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>high quality Carpentry Services</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			            <div class="item">
			            	<img src="img/slide-two.jpg" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>high quality Carpentry Services</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			            <div class="item">
			            	<img src="img/slide-three.jpg" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               				<p>high quality Carpentry Services</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			            <div class="item">
			            	<img src="img/slide-four.jpg" alt="">
			                <div class="carousel-caption">
		               			<h1>providing</h1>
		               			<p>high quality Carpentry Services</p>
		               			<button>learn more</button>
			                </div>
			            </div>
			        </div>
			        <!-- Controls -->
			        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
			            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
			            <span class="sr-only">Previous</span>
			        </a>
			        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
			            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
			            <span class="sr-only">Next</span>
			        </a>
			    </div>
			</div>
		</div>
	</section><!-- end of slider section -->

	<!-- about section -->
	<section class="about text-center" id="about">
		<div class="container">
			<div class="row">
				<h2>About John Marshall Carpentry</h2>
				<h4>I pride myself on excellent communication and promptness, integrity and attention to detail.<br /> I don't take short cuts and compromise the quality of my work. <br />You will always get my best with a smile. 
<br />
</h4>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail clearfix">
						<div class="about-img">
							<img class="img-responsive" src="img/item1.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>P</h1>
							</div>
							<h3>Pergolas</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="img/item2.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>D</h1>
							</div>

							<h3>Decks</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="img/item3.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>S</h1>
							</div>
							<h3>Shop Fitouts</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
                
                				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="img/item5.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>H</h1>
							</div>
							<h3>Home Renovations</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
                
                                				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="img/item4.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>C</h1>
							</div>
							<h3>Commercial Work</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
                                				<div class="col-md-4 col-sm-6">
					<div class="single-about-detail">
						<div class="about-img">
							<img class="img-responsive" src="img/item6.jpg" alt="">
						</div>
						<div class="about-details">
							<div class="pentagon-text">
								<h1>F</h1>
							</div>
							<h3>Furnishing</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of about section -->


	<!-- team section -->
	<section class="team" id="team">
		<div class="container">
			<div class="row">
				<div class="team-heading text-center">
					<h2>Gallery</h2>
					<h4>Some of the latest work that we have created </h4>
				</div>
				
			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal1.jpg" alt="..."/></a>

    </div>
    	<!--		<div class="col-xs-6 col-sm-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal2.jpg" alt="...">

    </div> -->
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal3.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal4.jpg" alt="..."/></a>

    </div>
    

    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal6.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal7.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal8.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal9.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal10.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal1.jpg" alt="..."></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal12.jpg" alt="..."/></a>

    </div>

    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal14.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal15.jpg" alt="..."/></a>

    </div>
    
        			<div class="col-xs-3">
        <a href="#" class="thumbnail  border-none" data-toggle="modal" data-target="#lightbox"> 
            <img src="img/gal16.jpg" alt="..."/></a>

    </div>



<div id="lightbox" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <button type="button" class="close hidden" data-dismiss="modal" aria-hidden="true">×</button>
        <div class="modal-content">
            <div class="modal-body">
                <img src="" alt="" />
            </div>
        </div>
    </div>
				
		
		
			</div>
		</div>
	</section><!-- end of team section -->

	<!-- map section -->
	<div class="api-map" id="contact">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12 map" id="map"></div>
			</div>
		</div>
	</div><!-- end of map section -->

	<!-- contact section starts here -->
	<section class="contact">
		<div class="container">
			<div class="row">
				<div class="contact-caption clearfix">
					<div class="contact-heading text-center">
						<h2>contact us</h2>
					</div>
					<div class="col-md-5 contact-info text-left">
						<h3>contact information</h3>
						<div class="info-detail">
							<ul><li><i class="fa fa-calendar"></i><span>Monday - Friday:</span> 9:30 AM to 6:30 PM</li></ul>
							<ul><li><i class="fa fa-map-marker"></i><span>Address:</span> Ngunnawal ACT 2913
</li></ul>
							<ul><li><i class="fa fa-phone"></i><span>Phone:</span> 0418 620 961
Re</li></ul>
					
							<ul><li><i class="fa fa-envelope"></i><span>Email:</span> info@johnmarshallcarpentry.co.au</li></ul>
						</div>
					</div>
					<div class="col-md-6 col-md-offset-1 contact-form">
						<h3>leave us a message</h3>

						<form class="form">
							<input class="name" type="text" placeholder="Name">
							<input class="email" type="email" placeholder="Email">
							<input class="phone" type="text" placeholder="Phone No:">
							<textarea class="message" name="message" id="message" cols="30" rows="10" placeholder="Message"></textarea>
							<input class="submit-btn" type="submit" value="SUBMIT">
						</form>
					</div>
				</div>
			</div>
		</div>
	</section><!-- end of contact section -->
<?php include 'footer.php' ?>